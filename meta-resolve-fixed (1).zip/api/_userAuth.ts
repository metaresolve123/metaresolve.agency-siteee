import crypto from 'crypto';

// ---------------------------------------------------------------------------
// Stateless visitor-session helpers for Vercel serverless functions.
// Vercel has no persistent disk, so sessions are HMAC-signed tokens instead of
// rows in data/user_sessions.json.
// ---------------------------------------------------------------------------

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  authProvider: 'local' | 'google';
  avatarUrl?: string;
  createdAt: string;
}

const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

function getSecret(): string {
  return (
    process.env.SESSION_SECRET ||
    process.env.GOOGLE_CLIENT_SECRET ||
    process.env.ADMIN_PASSWORD ||
    'change-me-set-SESSION_SECRET-in-vercel'
  );
}

const b64url = (buf: Buffer | string) =>
  Buffer.from(buf).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

const fromB64url = (str: string) =>
  Buffer.from(str.replace(/-/g, '+').replace(/_/g, '/'), 'base64');

export function signSession(user: SessionUser): string {
  const payload = b64url(JSON.stringify({ user, exp: Date.now() + SESSION_TTL_MS }));
  const sig = b64url(crypto.createHmac('sha256', getSecret()).update(payload).digest());
  return `${payload}.${sig}`;
}

export function verifySession(token: string): SessionUser | null {
  try {
    const [payload, sig] = String(token || '').split('.');
    if (!payload || !sig) return null;
    const expected = b64url(crypto.createHmac('sha256', getSecret()).update(payload).digest());
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    const data = JSON.parse(fromB64url(payload).toString('utf-8'));
    if (!data?.exp || Date.now() > data.exp) return null;
    return data.user as SessionUser;
  } catch {
    return null;
  }
}

export function getBearerToken(req: any): string {
  const h = req.headers?.authorization || req.headers?.Authorization;
  if (h && typeof h === 'string' && h.startsWith('Bearer ')) return h.substring(7).trim();
  if (req.query?.token) return String(req.query.token).trim();
  if (req.body?.token) return String(req.body.token).trim();
  return '';
}

// Base URL of the deployed site (used for the Google redirect URI).
export function getBaseUrl(req: any): string {
  const fromEnv = (process.env.APP_URL || '').trim().replace(/\/$/, '');
  if (fromEnv && !fromEnv.startsWith('MY_')) return fromEnv;
  const host = (req.headers?.['x-forwarded-host'] || req.headers?.host || '').toString().split(',')[0].trim();
  const proto = (req.headers?.['x-forwarded-proto'] || 'https').toString().split(',')[0].trim();
  return `${proto}://${host}`;
}

export const getGoogleClientId = () =>
  (process.env.GOOGLE_CLIENT_ID || process.env.VITE_GOOGLE_CLIENT_ID || '').trim();

export const getGoogleClientSecret = () => (process.env.GOOGLE_CLIENT_SECRET || '').trim();

export function escapeHtml(s: string): string {
  return String(s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } as Record<string, string>
  )[c]);
}
