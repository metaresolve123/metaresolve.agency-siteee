// Sessions are stateless signed tokens, so logging out just means the client drops the token.
export default function handler(_req: any, res: any) {
  return res.status(200).json({ success: true, message: 'Logged out successfully.' });
}
