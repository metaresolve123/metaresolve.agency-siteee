// Email/password accounts need a database, and Vercel has no persistent disk
// (data/users.json cannot be written there). Until a DB is connected, tell the visitor clearly.
export default function handler(_req: any, res: any) {
  return res.status(503).json({
    success: false,
    error: 'Email sign-in is temporarily unavailable. Please use "Continue with Google".',
  });
}
