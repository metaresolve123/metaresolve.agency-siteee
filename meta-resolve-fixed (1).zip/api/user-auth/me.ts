import { getBearerToken, verifySession } from '../_userAuth';

export default function handler(req: any, res: any) {
  const token = getBearerToken(req);
  if (!token) {
    return res.status(401).json({ success: false, error: 'No authentication token provided.' });
  }
  const user = verifySession(token);
  if (!user) {
    return res.status(401).json({ success: false, error: 'Session is invalid or expired. Please sign in.' });
  }
  return res.status(200).json({ success: true, user });
}
