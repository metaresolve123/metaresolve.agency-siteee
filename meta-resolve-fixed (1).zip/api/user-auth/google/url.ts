import { getBaseUrl, getGoogleClientId } from '../../_userAuth';

export default function handler(req: any, res: any) {
  const clientId = getGoogleClientId();
  if (!clientId) {
    return res.status(200).json({
      success: false,
      configured: false,
      error: 'Google sign-in is not set up yet (GOOGLE_CLIENT_ID missing in Vercel environment variables).',
    });
  }

  const redirectUri = `${getBaseUrl(req)}/api/user-auth/google/callback`;
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    prompt: 'select_account',
  });

  return res.status(200).json({
    success: true,
    configured: true,
    url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`,
  });
}
