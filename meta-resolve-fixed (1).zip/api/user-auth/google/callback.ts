import {
  SessionUser,
  escapeHtml,
  getBaseUrl,
  getGoogleClientId,
  getGoogleClientSecret,
  signSession,
} from '../../_userAuth';

const page = (body: string) => `<!DOCTYPE html><html><body style="background:#090D0D;color:#F2F5EF;font-family:sans-serif;padding:30px;text-align:center;">${body}</body></html>`;

const errorPage = (message: string) =>
  page(`
    <h3>Google Authentication Failed</h3>
    <p style="color:#FF7777;font-size:14px;">${escapeHtml(message)}</p>
    <script>
      if (window.opener) {
        window.opener.postMessage({ type: 'OAUTH_AUTH_ERROR', error: ${JSON.stringify(message)} }, window.location.origin);
        setTimeout(() => window.close(), 2500);
      }
    </script>`);

export default async function handler(req: any, res: any) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');

  const { code, error } = req.query || {};
  if (error || !code) {
    return res.status(200).send(errorPage(String(error || 'Authorization code was not provided.')));
  }

  try {
    const clientId = getGoogleClientId();
    const clientSecret = getGoogleClientSecret();
    if (!clientId || !clientSecret) {
      throw new Error('GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET are not set in Vercel.');
    }

    const redirectUri = `${getBaseUrl(req)}/api/user-auth/google/callback`;

    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code: String(code),
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }).toString(),
    });
    const tokenData: any = await tokenRes.json();
    if (!tokenRes.ok || !tokenData.access_token) {
      throw new Error(tokenData.error_description || tokenData.error || 'Token exchange failed');
    }

    const profileRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const profile: any = await profileRes.json();
    if (!profile.email) throw new Error('Google account email could not be retrieved.');

    const user: SessionUser = {
      id: `google_${profile.id}`,
      name: profile.name || String(profile.email).split('@')[0],
      email: profile.email,
      authProvider: 'google',
      avatarUrl: profile.picture,
      createdAt: new Date().toISOString(),
    };
    const token = signSession(user);

    return res.status(200).send(
      page(`
        <h3 style="color:#B7FF35;">Authentication Successful</h3>
        <p style="color:#A0AAA3;font-size:14px;">Connecting to META RESOLVE...</p>
        <script>
          if (window.opener) {
            window.opener.postMessage({
              type: 'OAUTH_AUTH_SUCCESS',
              token: ${JSON.stringify(token)},
              user: ${JSON.stringify(user)}
            }, window.location.origin);
            window.close();
          } else {
            window.location.href = '/';
          }
        </script>`)
    );
  } catch (err: any) {
    console.error('Google OAuth callback error:', err);
    return res.status(200).send(errorPage(err?.message || 'Error processing Google sign in'));
  }
}
